import time,os
import pyautogui

screenWidth, screenHeight = pyautogui.size()

# x1, y1 = pyautogui.position()
# x2, y2 = pyautogui.position()
x1, y1 = 72, 240
x2, y2 = 1616, 1034

# pyautogui.moveTo(0, 0, duration=0.1)

# time.sleep(0.1)
# help(pyautogui)

# # ctrl+c 复制⽂字
# pyautogui.hotkey('ctrl', 'c')  
# # ctrl+v 粘贴⽂字
# pyautogui.hotkey('ctrl', 'v')


img_path = 'map_01.png'
im = pyautogui.screenshot(region=(x1, y1, x2, y2))
im.save(img_path) # 保存图片

img_path = 'map_02.png'
pyautogui.click(x1, y1)
time.sleep(0.3)
# pyautogui.click(x1, y1)
# time.sleep(0.3)
im = pyautogui.screenshot()
im.save(img_path) # 保存图片

img_path = 'map_03.png'
pyautogui.click(x2, y2)
time.sleep(0.3)
# pyautogui.click(x2, y2)
# time.sleep(0.3)
im = pyautogui.screenshot()
im.save(img_path) # 保存图片


